//if (window.location.search.indexOf("dtinject=false") == -1) {
/** @typedef {Object.<string, string|number|boolean|symbol|Array>} ModuleConfig 
 * @property {boolean} enabled
*/

/**
 * @typedef {Object} ButtonStyleInfo
 * @property {String} normalStyle the style ID of the normal button style
 * @property {String} hoverStyle the style ID of the style for when the button is hovered over
 * @property {String} hoverSelectedStyle the style ID of the style for when the button is hovered over while it's selected
 * @property {String} selectedStyle the style ID of the the style for when the category is selected
*/

/**
 * @typedef {Object} TrayButtonInfo
 * @property {String} content The text content that will go inside the button
 * @property {Boolean} deleteTrayWhenClicked Whether the tray should be deleted when the button is clicked
 * @property {function(boolean, ModuleConfig)} onClickCallback The callback for when the button is clicked
 * @property {String} moduleName The name of the module for the tray button. Is util, and if set will get overriden
 */

/**
 * @typedef {Object} ButtonInfo
 * @property {String} name The text content to be displayed inside the button
 * @property {Function} onClicked callback function for when the button is clicked
 * @property {ButtonStyleInfo} style Style info for this button. If none is specified, then will use default
*/

const contentInjectInfo = {
    /** @type {Object.<string, ModuleConfig>} */
    "user_config": {
        "date": {
            "year": false
        },
        "lagmeter": {
            "spinner": true
        },
        "school": {
            "enabled": false
        },
        "battery": {
            "enabled": false
        },
        "coderunner": {
            "enabled": false
        }
    },
    /** Info about the content inject */
    "info": {
        "name": "Content Inject",
        "version": "0.9.1",
        "author": "Fluffy Doggo",
        "description": "Creates a useful inject",
        "credits": [
            "Sethtek Dev for supporting this"
        ]
    },
    "options": {
        "currentStyle": "",
        "defaultStyle": {
            "enabled": true,
            "offsetBottom": 0,
            "offsetLeft": 0,
            "options": ""
        },
        "base": {
            "bottom": 44,
            "left": 0
        },
        "urlStyles": [
            {
                "url": "",
                "enabled": true,
                "offsetBottom": 0,
                "offsetLeft": 0,
                "options": ""
            }
        ],
        "updateTime": 250,
        /** @type {Object.<string, ModuleConfig>} */
        "moduleConfig": {},
        "styles": {}
    },
    "functions": {
        "update": function() {
            contentInjectInfo.contentButton.textContent = contentInjectInfo._modules.map((contentInjectModule) => {
                let config = contentInjectInfo.options.moduleConfig[contentInjectModule.name];

                return contentInjectModule.onRequestContent(config.enabled, config);
            })
            .filter(item => item !== "")
            .join("; ");
        },
        "renderInfo": function(element, name, value, isArray = false) {
            let renderedTitle = document.createElement("b");
            renderedTitle.textContent = name;
            element.appendChild(renderedTitle);

            element.appendChild(document.createElement("br"));

            let renderedValue = document.createElement("span");

            if (isArray) {
                let joinedValue = value.map(val => JSON.stringify(val)).join("<br/>");

                renderedValue.innerHTML = joinedValue;
            }
            else {
                renderedValue.innerHTML = JSON.stringify(value);
            }
            
            element.appendChild(renderedValue);
            element.appendChild(document.createElement("br"));
        },
        /**
         * Sets the style for the content inject. Must be called before initializing the content inject
         * @param {Object.<string, object>} style
         */
        "setStyle": function(style) {
            contentInjectInfo.options.styles = style;
        },
        /**
         * Adds a style to a specific element
         * @param {HTMLElement} element
         * @param {String} styleID
        */
        "addStyle": function(element, styleID) {
            let requestedStyle = contentInjectInfo.options.styles[styleID];
            if (requestedStyle) {
                Object.keys(requestedStyle).forEach(styleDeclaration => element.style[styleDeclaration] = requestedStyle[styleDeclaration]);
            }
        },
        "addStyleInfo": function(newName, style, styleDiv, buttonEl, styleVal = "") {
            let styleLabel = document.createElement("span");
            styleLabel.setAttribute("style-name", newName);
            styleLabel.setAttribute("style-for", style);
            styleLabel.setAttribute("style-display", "label");

            styleLabel.classList.add("content-inject-module-style-element-" + contentInjectInfo.baseID);

            styleLabel.textContent = newName + ": ";

            styleDiv.appendChild(styleLabel);
            
            let styleValue = document.createElement("input");

            styleValue.setAttribute("style-name", newName);
            styleValue.setAttribute("style-for", style);
            styleValue.setAttribute("style-display", "input");

            this.addStyle(styleValue, "styleTextInput");

            styleValue.classList.add("content-inject-module-style-" + contentInjectInfo.baseID);
            styleValue.classList.add("content-inject-module-style-element-" + contentInjectInfo.baseID);

            styleValue.type = "text";

            styleValue.value = styleVal;

            let removeStyleButton = document.createElement("button");
            removeStyleButton.setAttribute("style-name", newName);
            removeStyleButton.setAttribute("style-for", style);
            removeStyleButton.setAttribute("style-display", "button");
            removeStyleButton.textContent = "-";
            removeStyleButton.classList.add("content-inject-module-style-element-" + contentInjectInfo.baseID);
            this.addStyle(removeStyleButton, "removeStyleButton");

            let brElement = document.createElement("br");
            brElement.setAttribute("style-name", newName);
            brElement.setAttribute("style-for", style);
            brElement.classList.add("content-inject-module-style-element-" + contentInjectInfo.baseID);



            removeStyleButton.addEventListener("click", (ev) => {
                let allStyleElements = document.getElementsByClassName("content-inject-module-style-element-" + contentInjectInfo.baseID);

                let myStyleFor = ev.srcElement.getAttribute("style-for");
                let myStyleName = ev.srcElement.getAttribute("style-name");

                let elementsToDelete = [];

                for (let i = 0, len = allStyleElements.length; i < len; i++) {
                    let element = allStyleElements[i];

                    if (!element) continue;

                    let elStyleFor = element.getAttribute("style-for");
                    let elStyleName = element.getAttribute("style-name");

                    if (myStyleFor == elStyleFor && myStyleName == elStyleName) {

                        if (element.getAttribute("style-display") == "button") {
                            elementsToDelete.push(element);
                        }
                        else {
                            elementsToDelete.unshift(element);
                        }
                    }
                }

                elementsToDelete.forEach(element => ev.srcElement.parentElement.removeChild(element));
            });

            let addStyleButton = buttonEl ? styleDiv.removeChild(buttonEl) : undefined;

            styleDiv.appendChild(styleValue);
            styleDiv.appendChild(removeStyleButton);
            styleDiv.appendChild(brElement);

            if (addStyleButton) styleDiv.appendChild(addStyleButton);
        },
        "updateContent": function(optionsContentDiv) {
            if (contentInjectInfo.contentButton) {
                this.addStyle(contentInjectInfo.contentButton, "contentButton");
            }

            if (contentInjectInfo.optionsPage) {
                this.addStyle(contentInjectInfo.optionsPage, "optionsDiv");
            }

            this.addStyle(optionsContentDiv, "optionsContentDiv");
        },
        "displayLoadedInfo": function() {
            let mainContent = document.getElementById("content-inject-options-content-" + contentInjectInfo.baseID);

            if (mainContent) {
                mainContent.innerHTML = "";
                
                let content = [];
                Object.keys(contentInjectInfo.info).forEach(key => {
                    let infoItem = contentInjectInfo.info[key];
                    
                    let label = document.createElement("b");
                    label.textContent = contentInjectInfo.functions.titleCase(key);
                        
                    content.push(label);
                    
                    if (Array.isArray(infoItem)) {
                        label.classList.add(contentInjectInfo.optionsItemNoBRClass);
                        
                        infoItem.forEach(item => {
                            let listItem = document.createElement("li");
                            listItem.textContent = item.toString();
                            listItem.classList.add(contentInjectInfo.optionsItemNoBRClass);
                            
                            content.push(listItem);
                        });
                    }
                    else {
                        let textElement = document.createElement("span");
                        textElement.textContent = infoItem.toString();
                        textElement.classList.add(contentInjectInfo.optionsItemNoBRClass);
                        
                        content.push(textElement);
                    }
                        
                    let brElement = document.createElement("br");
                    content.push(brElement);
                });
                
                content.forEach((contentItem, index) => {
                    mainContent.appendChild(contentItem);
                    
                    if (index < content.length - 1 && !contentItem.classList.contains(contentInjectInfo.optionsItemNoBRClass)) {
                        mainContent.appendChild(document.createElement("br"));
                    }
                });
            }
        },
        "displayModuleOptions": function() {
            let mainContent = document.getElementById("content-inject-options-content-" + contentInjectInfo.baseID);

            if (mainContent) {
                mainContent.innerHTML = "";
                
                let content = [];
                    
                let saveButton = document.createElement("button");
                saveButton.textContent = "Save";
                saveButton.addEventListener("click", () => {
                    let configElements = document.getElementsByClassName("content-inject-module-option-" + contentInjectInfo.baseID);

                    for (let i = 0, len = configElements.length; i < len; i++) {
                        let element = configElements[i];

                        let configType = element.getAttribute("config-type");
                        let configEntry = element.getAttribute("config-name");
                        let moduleEntry = element.getAttribute("module-name");
                        
                        if (configEntry && moduleEntry) {
                            if (contentInjectInfo.options.moduleConfig[moduleEntry]) {
                                if (configType == "boolean") {
                                    contentInjectInfo.options.moduleConfig[moduleEntry][configEntry] = element.checked;
                                }
                                else if (configType == "string") {
                                    contentInjectInfo.options.moduleConfig[moduleEntry][configEntry] = element.value;
                                }
                                else if (configType == "number") {
                                    contentInjectInfo.options.moduleConfig[moduleEntry][configEntry] = parseFloat(element.value);
                                }
                            }
                        }
                    }
                });
                
                content.push(saveButton);
                content.push(document.createElement("br"));
                content.push(document.createElement("br"));
                
                Object.keys(contentInjectInfo.options.moduleConfig).forEach((key) => {
                    let toggleButton = document.createElement("button");
                    toggleButton.textContent = key;
                    toggleButton.setAttribute("toggledID", "content-inject-option-" + contentInjectInfo.baseID + "-" + key);
                    toggleButton.addEventListener("click", (ev) => {
                        let toggledID = ev.srcElement.getAttribute("toggledID");
                        
                        if (toggledID) {
                            let toggledContent = document.getElementById(toggledID);
                            
                            if (toggledContent) {
                                toggledContent.style.display = toggledContent.style.display == "none" ? "block" : "none";
                            }
                        }
                    });
                    
                    content.push(toggleButton);
                    content.push(document.createElement("br"));
                    
                    let contentContainer = document.createElement("div");
                    contentContainer.id = "content-inject-option-" + contentInjectInfo.baseID + "-" + key;
                    contentContainer.style.display = "none";
                    
                    let mainTable = document.createElement("table");
                    contentInjectInfo.functions.addStyle(mainTable, "moduleOptionsTable");
                    
                    Object.keys(contentInjectInfo.options.moduleConfig[key]).forEach(configName => {
                        let mainTableRow = document.createElement("tr");
                        contentInjectInfo.functions.addStyle(mainTableRow, "moduleOptionsTableRow");

                        let configLabelTableData = document.createElement("td");
                        contentInjectInfo.functions.addStyle(configLabelTableData, "moduleOptionsTableData");

                        let configLabel = document.createElement("span");
                        configLabel.textContent = configName;
                        contentInjectInfo.functions.addStyle(configLabel, "moduleOptionsTableConfigLabel");

                        configLabelTableData.appendChild(configLabel);

                        let configContentTableData = document.createElement("td");
                        contentInjectInfo.functions.addStyle(configContentTableData, "moduleOptionsTableData");
                        
                        // if (configName == "enabled") {
                        //     let checkbox = document.createElement("input");
                        //     checkbox.type = "checkbox";
                        //     checkbox.classList.add("content-inject-module-option-" + contentInjectInfo.baseID);
                        //     checkbox.setAttribute("config-name", configName);
                        //     checkbox.setAttribute("module-name", key);
                        //     checkbox.setAttribute("config-type", "boolean");
                        //     checkbox.checked = contentInjectInfo.options.moduleConfig[key][configName];
                            
                        //     contentContainer.appendChild(checkbox);
                        // }
                        // else 
                        if (configName == "enabled" || typeof contentInjectInfo.options.moduleConfig[key][configName] === 'boolean') {
                            let checkbox = document.createElement("input");
                            checkbox.type = "checkbox";
                            checkbox.classList.add("content-inject-module-option-" + contentInjectInfo.baseID);
                            checkbox.setAttribute("config-name", configName);
                            checkbox.setAttribute("module-name", key);
                            checkbox.setAttribute("config-type", "boolean");
                            checkbox.checked = contentInjectInfo.options.moduleConfig[key][configName];
                            
                            configContentTableData.appendChild(checkbox);
                        }
                        else if (typeof contentInjectInfo.options.moduleConfig[key][configName] === 'string') {
                            let textbox = document.createElement("input");
                            textbox.type = "text";
                            textbox.id = "content-inject-options-input-" + contentInjectInfo.baseID;
                            textbox.classList.add("content-inject-module-option-" + contentInjectInfo.baseID);
                            textbox.setAttribute("config-name", configName);
                            textbox.setAttribute("module-name", key);
                            textbox.setAttribute("config-type", "string");
                            textbox.value = contentInjectInfo.options.moduleConfig[key][configName];

                            configContentTableData.appendChild(textbox);
                        }
                        else if (typeof contentInjectInfo.options.moduleConfig[key][configName] === 'number') {
                            let numberbox = document.createElement("input");
                            numberbox.type = "number";
                            numberbox.id = "content-inject-options-input-" + contentInjectInfo.baseID;
                            numberbox.classList.add("content-inject-module-option-" + contentInjectInfo.baseID);
                            numberbox.setAttribute("config-name", configName);
                            numberbox.setAttribute("module-name", key);
                            numberbox.setAttribute("config-type", "number");
                            numberbox.value = contentInjectInfo.options.moduleConfig[key][configName];

                            configContentTableData.appendChild(numberbox);
                        }
                        else {
                            configContentTableData.textContent = "Unknown Data";
                        }

                        mainTableRow.appendChild(configLabelTableData);
                        mainTableRow.appendChild(configContentTableData);
                        
                        mainTable.appendChild(mainTableRow);
                    });
                    
                    contentContainer.appendChild(mainTable);
                    
                    content.push(contentContainer);
                });
                
                content.forEach(element => mainContent.appendChild(element));
            }
        },
        "displayLoadedModules": function() {
            let mainContent = document.getElementById("content-inject-options-content-" + contentInjectInfo.baseID);

            if (mainContent) {
                mainContent.innerHTML = contentInjectInfo._modules
                // convert each module so it displays it status of enabled/disabled with html. Used a seperate function so it looks nicer. What it does is strip html from the name, aka < and >, and replaces & with &amp; At the beginning of the string will show a span set to a specific color with a dot inside it
                .map(contentInjectModule => ContentInjectModule.getStatus(contentInjectModule))
                // filter out blank statuses (aka module doesn't exist, so returns empty string)
                .filter(item => item !== "")
                // join all modules to a string, seperated by "<br/>"
                .join("<br/>");
            }
        },
        "displayStyleSettings": function() {
            let mainContent = document.getElementById("content-inject-options-content-" + contentInjectInfo.baseID);

            if (mainContent) {
                mainContent.innerHTML = "";

                let content = [];

                let saveButton = document.createElement("button");
                saveButton.textContent = "Save";
                saveButton.addEventListener("click", () => {
                    let configStyleElements = document.getElementsByClassName("content-inject-module-style-" + contentInjectInfo.baseID);
                    
                    Object.keys(contentInjectInfo.options.styles).forEach(styleCategory => {
                        // update all elements that are available 
                        Object.keys(contentInjectInfo.options.styles[styleCategory]).forEach(styleKey => contentInjectInfo.options.styles[styleCategory][styleKey] = "");
                        contentInjectInfo.functions.updateContent(mainContent);

                        contentInjectInfo.options.styles[styleCategory] = {};
                    });

                    for (let i = 0, len = configStyleElements.length; i < len; i++) {
                        let element = configStyleElements[i];

                        let styleName = element.getAttribute("style-name");
                        let styleFor = element.getAttribute("style-for");

                        let style = contentInjectInfo.options.styles[styleFor];
                        
                        // removed to fix bug of empty styles being like: and I bork
                        // if (!style) {
                        //     contentInjectInfo.options.styles[styleFor] = {};
                        //     // re-reference it so when values are updated, they update the object in the options
                        //     console.log('im needed')
                        //     style = contentInjectInfo.options.styles[styleFor];
                        // }
                        
                        style[styleName] = element.value;

                    }

                    contentInjectInfo.functions.updateContent(mainContent);
                });

                content.push(saveButton);

                let exportTextArea = document.createElement("textarea");
                exportTextArea.id = "content-inject-styles-export-textarea-" + contentInjectInfo.baseID;
                contentInjectInfo.functions.addStyle(exportTextArea, "exportTextArea");

                let exportButton = document.createElement("button");
                exportButton.textContent = "Export";
                exportButton.addEventListener("click", () => {
                    let textAreaToExportTo = document.getElementById("content-inject-styles-export-textarea-" + contentInjectInfo.baseID);

                    if (textAreaToExportTo) {
                        textAreaToExportTo.value = `contentInjectInfo.functions.setStyle(${JSON.stringify(contentInjectInfo.options.styles)});`;
                        contentInjectInfo.functions.addStyle(exportTextArea, "exportTextAreaShown");
                    }
                });
                
                content.push(exportButton);

                content.push(document.createElement("br"));

                content.push(exportTextArea);

                content.push(document.createElement("br"));
                content.push(document.createElement("br"));
                content.push(document.createElement("br"));

                Object.keys(contentInjectInfo.options.styles).forEach(style => {
                    let textLabel = document.createElement("b");

                    textLabel.textContent = style;

                    content.push(textLabel);
                    content.push(document.createElement("br"));

                    let styleContainer = document.createElement("div");
                    styleContainer.id = "content-inject-style-" + style + "-" + contentInjectInfo.baseID;
                    contentInjectInfo.functions.addStyle(styleContainer, "styleOptionCategoryDiv");

                    Object.keys(contentInjectInfo.options.styles[style]).forEach(contentStyle => {
                        contentInjectInfo.functions.addStyleInfo(contentStyle, style, styleContainer, undefined, contentInjectInfo.options.styles[style][contentStyle]);
                    });

                    let addNewStyleButton = document.createElement("button");
                    addNewStyleButton.textContent = "+";
                    addNewStyleButton.setAttribute("style-for", style);
                    
                    contentInjectInfo.functions.addStyle(addNewStyleButton, "addStyleButton");

                    addNewStyleButton.addEventListener("click", (ev) => {
                        let styleFor = ev.srcElement.getAttribute("style-for");

                        if (styleFor) {
                            let styleDiv = document.getElementById("content-inject-style-" + styleFor + "-" + contentInjectInfo.baseID);

                            if (styleDiv) {
                                let newName = prompt("Enter the style name");

                                if (newName) {
                                    for (let i = 0, len = styleDiv.children.length; i < len; i++) {
                                        if (styleDiv.children[i].getAttribute("style-for") === newName && styleDiv.children[i].getAttribute("style-display") == "input") {
                                            alert("Sorry, that name already exists");
                                            return;
                                        }
                                    }

                                    contentInjectInfo.functions.addStyleInfo(newName, styleFor, styleDiv, ev.srcElement);
                                }
                            }
                        }
                    });
                    styleContainer.appendChild(addNewStyleButton);

                    content.push(styleContainer);

                    content.push(document.createElement("br"));
                    content.push(document.createElement("br"));
                });

                content.forEach(element => mainContent.appendChild(element));
            }
        },
        /** @param {MouseEvent} ev */
        "closeSettings": function(ev) {
            let categoryIDstring = ev.target.getAttribute("content-inject-button-category-id");

            if (categoryIDstring) {
                let categoryID = parseInt(categoryIDstring);

                let categoryIndex = contentInjectInfo._categoryIDs.indexOf(categoryID);

                if (categoryIndex > -1) {
                    contentInjectInfo._categoryIDs.splice(categoryIndex, 1);
                }
            }

            if (contentInjectInfo.optionsPage != undefined) {
                contentInjectInfo.optionsPage.parentNode.removeChild(contentInjectInfo.optionsPage);
                contentInjectInfo.optionsPage = undefined;
            }
        },
        "getCategoryID": function() {
            let prevCategoryID = 0;

            for (let i = 0, len = contentInjectInfo._categoryIDs; i < len; i++) {
                if (prevCategoryID - contentInjectInfo._categoryIDs[i] > 1) {
                    return prevCategoryID;
                }

                prevCategoryID = contentInjectInfo._categoryIDs[i];
            }

            return prevCategoryID;
        },
        /**
         * @param {ButtonStyleInfo} buttonStyle The default style info for the buttons
         * @param {ButtonInfo[]} buttonsInfo The buttons and their info
         */
        "createCategoryButtons": function(buttonStyle, ...buttonsInfo) {
            /** @type {HTMLButtonElement[]} */
            let createdButtons = [];
            let buttonCategoryID = this.getCategoryID();

            buttonsInfo.forEach(buttonInfo => {
                let createdButton = document.createElement("button");

                let normalStyle = (buttonInfo.style != undefined && buttonInfo.style.normalStyle != undefined) ? buttonInfo.style.normalStyle : buttonStyle.normalStyle;

                let hoverStyle = (buttonInfo.style != undefined && buttonInfo.style.hoverStyle != undefined) ? buttonInfo.style.hoverStyle : buttonStyle.hoverStyle;

                let hoverSelectedStyle = (buttonInfo.style != undefined && buttonInfo.style.hoverSelectedStyle != undefined) ? buttonInfo.style.hoverSelectedStyle : buttonStyle.hoverSelectedStyle;

                let selectedStyle = (buttonInfo.style != undefined && buttonInfo.style.selectedStyle != undefined) ? buttonInfo.style.selectedStyle : buttonStyle.selectedStyle;

                createdButton.setAttribute("content-inject-normal-style-" + contentInjectInfo.baseID, normalStyle);
                createdButton.setAttribute("content-inject-hover-style-" + contentInjectInfo.baseID, hoverStyle);
                createdButton.setAttribute("content-inject-hover-selected-style-" + contentInjectInfo.baseID, hoverSelectedStyle);
                createdButton.setAttribute("content-inject-selected-style-" + contentInjectInfo.baseID, selectedStyle);

                createdButton.setAttribute("content-inject-isselected", "false");

                createdButton.setAttribute("content-inject-button-category-id", buttonCategoryID);

                createdButton.classList.add("content-inject-category-button-" + buttonCategoryID + "-" + contentInjectInfo.baseID);
                
                this.addStyle(createdButton, normalStyle);

                createdButton.addEventListener("mouseover", (ev) => {
                    let wantedStyle = ev.target.getAttribute(`content-inject-hover${ev.target.getAttribute("content-inject-isselected") == "true" ? "-selected" : ""}-style-${contentInjectInfo.baseID}`);

                    if (!wantedStyle) return;

                    contentInjectInfo.functions.addStyle(ev.target, wantedStyle);
                });
                
                createdButton.addEventListener("mouseleave", (ev) => {
                    let wantedStyle = ev.target.getAttribute(`content-inject-${ev.target.getAttribute("content-inject-isselected") == "true" ? "selected" : "normal"}-style-${contentInjectInfo.baseID}`);

                    if (!wantedStyle) return;

                    contentInjectInfo.functions.addStyle(ev.target, wantedStyle);
                });

                createdButton.addEventListener("click", (ev) => {
                    let categoryID = ev.target.getAttribute(`content-inject-button-category-id`);

                    if (categoryID) {
                        let sameCategoryButtons = document.getElementsByClassName(`content-inject-category-button-${categoryID}-${contentInjectInfo.baseID}`);

                        for (let i = 0, len = sameCategoryButtons.length; i < len; i++) {
                            let categoryButton = sameCategoryButtons[i];

                            categoryButton.setAttribute("content-inject-isselected", "false");

                            contentInjectInfo.functions.addStyle(categoryButton, categoryButton.getAttribute(`content-inject-normal-style-${contentInjectInfo.baseID}`));
                        }

                        ev.target.setAttribute("content-inject-isselected", "true");
                        contentInjectInfo.functions.addStyle(ev.target, ev.target.getAttribute(`content-inject-hover-selected-style-${contentInjectInfo.baseID}`));

                        buttonInfo.onClicked(ev);
                    }
                });

                createdButton.textContent = buttonInfo.name;

                createdButtons.push(createdButton);
            });

            if (contentInjectInfo._categoryIDs.length === 0) contentInjectInfo._categoryIDs.push(buttonCategoryID);
            else contentInjectInfo._categoryIDs.splice(buttonCategoryID + 1, 0, buttonCategoryID + 1);

            return createdButtons;
        },
        "showOptions": function() {
            if (contentInjectInfo.optionsPage) return;

            let settingsDiv = document.createElement("div");
            settingsDiv.id = "content-inject-options-" + contentInjectInfo.baseID;

            // add the style
            this.addStyle(settingsDiv, "optionsDiv");

            let categoryButtons = this.createCategoryButtons({"normalStyle": "categoryButtons", "hoverStyle": "categoryButtonsHover", "hoverSelectedStyle": "categoryButtonsSelectedHover", "selectedStyle": "categoryButtonsSelected"}, 
            {"name": "Style Settings", "onClicked": this.displayStyleSettings}, 
            {"name": "Loaded Modules", "onClicked": this.displayLoadedModules}, 
            {"name": "Module Options", "onClicked": this.displayModuleOptions}, 
            {"name": "Info", "onClicked": this.displayLoadedInfo}, 
            {"name": "Close", "onClicked": this.closeSettings});

            let divOptionsContent = document.createElement("div");
            divOptionsContent.id = "content-inject-options-content-" + contentInjectInfo.baseID;

            // add the styles
            this.addStyle(divOptionsContent, "optionsContentDiv");

            divOptionsContent.innerHTML = "<b>Click on a tab to view content</b>";
            
            categoryButtons.forEach(categoryButton => settingsDiv.appendChild(categoryButton));

            settingsDiv.appendChild(document.createElement("hr"));
            settingsDiv.appendChild(divOptionsContent);

            document.body.appendChild(settingsDiv);
            contentInjectInfo.optionsPage = settingsDiv;
        },
        "addTrayButton": function(container, content, moduleName, clickCallback, deleteWhenClicked = true) {
            let newTrayButton = document.createElement("button");
            
            newTrayButton.textContent = content;
            newTrayButton.setAttribute("content-inject-tray-button-delete-onclick-" + contentInjectInfo.baseID, deleteWhenClicked);
            newTrayButton.setAttribute("content-inject-tray-button-module-name-" + contentInjectInfo.baseID, moduleName);
            newTrayButton.addEventListener("click", (ev) => {
                let requestedModuleName = ev.target.getAttribute("content-inject-tray-button-module-name-" + contentInjectInfo.baseID);

                let moduleConfig = contentInjectInfo.options.moduleConfig[requestedModuleName];

                // I wonder if there's a way to set this to an attribute or something so memory isn't wasted on storing the clickCallback function
                if (moduleConfig) {
                    clickCallback(moduleConfig.enabled, moduleConfig);
                }
                else clickCallback();

                if (ev.target.getAttribute("content-inject-tray-button-delete-onclick-" + contentInjectInfo.baseID) == "true") {
                    ev.target.parentElement.parentNode.removeChild(ev.target.parentElement);
                }
            });

            this.addStyle(newTrayButton, "trayButton");

            container.appendChild(newTrayButton);
        },
        "showTray": function() {
            if (contentInjectInfo.tray) return;

            let trayContent = document.createElement("button");
            trayContent.id = "content-inject-tray-" + contentInjectInfo.baseID;

            this.addStyle(trayContent, "trayOptions");

            let optionsButton = document.createElement("button");
            optionsButton.textContent = "Options";
            optionsButton.addEventListener("click", () => {
                contentInjectInfo.functions.showOptions();

                let trayContainer = document.getElementById("content-inject-tray-" + contentInjectInfo.baseID);

                if (trayContainer) {
                    trayContainer.parentNode.removeChild(trayContainer);
                    contentInjectInfo.tray = undefined;
                }
            });

            this.addStyle(optionsButton, "trayButton");
            this.addStyle(optionsButton, "trayButtonLeft");

            trayContent.appendChild(optionsButton);

            contentInjectInfo._modules.map((contentInjectModule, index) => {
                let config = contentInjectInfo.options.moduleConfig[contentInjectModule.name];

                return contentInjectModule.onRequestTrayButtons(config.enabled, config).map(trayButton => {
                    // assign the tray button
                    trayButton.moduleName = contentInjectInfo._moduleNames[index];
                    return trayButton;
                });
            })
            // remove modules that exported no buttons
            .filter(item => item.length > 0)
            // run through each module, run through each tray button it exported, and attempt to add it to the tray
            .forEach(trayButtons => {
                trayButtons.forEach(trayButton => {
                    contentInjectInfo.functions.addTrayButton(trayContent, trayButton.content, trayButton.moduleName, trayButton.onClickCallback, trayButton.deleteTrayWhenClicked);
                });
            });

            let closeButton = document.createElement("button");
            closeButton.textContent = "Close";
            closeButton.addEventListener("click", () => {
                let trayContainer = document.getElementById("content-inject-tray-" + contentInjectInfo.baseID);

                if (trayContainer) {
                    trayContainer.parentNode.removeChild(trayContainer);
                    contentInjectInfo.tray = undefined;
                }
            });

            this.addStyle(closeButton, "trayButton");
            this.addStyle(closeButton, "trayButtonRight");

            trayContent.appendChild(closeButton);

            contentInjectInfo.tray = trayContent;

            document.body.appendChild(trayContent);
        },
        "titleCase": function(inp) {
            return inp.split(" ").map(word => word[0].toUpperCase() + word.slice(1, word.length).toLowerCase()).join(" ");
        }
    },
    "interval": 0,
    /** @type {HTMLButtonElement} */
    "contentButton": undefined,
    /** @type {HTMLDivElement} */
    "optionsPage": undefined,
    /** @type {HTMLButtonElement} */
    "tray": undefined,
    "baseID": "",
    "optionsItemClass": "",
    /** @type {String[]} */
    "_moduleNames": [],
    /** @type {ContentInjectModule[]} */
    "_modules": [],
    /** @type {Number[]} */
    "_categoryIDs": []
};

class AlreadyExistsError extends Error {
    /**
     * An error for when a certain resource exists
     * @param {String} objectName the name 
     * @param {String} resourceName the name of the resource
     * @param {String} resourcePropertyType the type of property wanted (like "id" or "name")
     * @param {String} resourcePropertyName the value specified for that property
     */
    constructor(resourceName, resourcePropertyType, resourcePropertyName) {
        super(`${resourceName} with ${resourcePropertyType} "${resourcePropertyName}" already exists`);
        this.resourcePropertyType = resourcePropertyType;
        this.resourcePropertyName = resourcePropertyName;
        this.resourceName = resourceName;
    }
}

class ContentInjectModule {
    /**
     * @param {String} name The name of the content inject module
     * @param {Object.<string, string|number|boolean|symbol|Array>} config The configuration options for this module
     * @param {Object.<string, ("string"|"number"|"boolean"|"symbol"|"array")} configTypes The configuration types for the config. That sounds very confusing, so pretty much you map the config you specified to a correlated value type. This is used for the **Module Options** tab in the settings
     * @throws `AlreadyExistsError` if a module of the same name already exists
     */
    constructor(name, config, configTypes) {
        if (contentInjectInfo._moduleNames.includes(name)) throw new AlreadyExistsError("ContentInjectModule", "name", name);
        let generatedConfig = {"enabled": true};
        let generatedConfigType = {"enabled": "boolean"};
        let autoGenerateConfigType = !(configTypes || Object.keys(configTypes).length === 0 && configTypes.constructor === Object);

        let userConfig = contentInjectInfo.user_config[name];
        if (userConfig) {
            if (userConfig.enabled === false) generatedConfig.enabled = false;
        }

        let configKeys = Object.keys(config);
        configKeys.forEach(key => {
            if (key == "enabled") console.warn(`"enabled" config option for module config is reserved, and cannot be set`);

            else if (typeof config[key] == 'object' && !Array.isArray(config[key])) console.warn('Objects are not allowed in content inject module configs');

            else {
                // allow setting your own config
                if (userConfig && userConfig[key] !== undefined) {
                    generatedConfig[key] = userConfig[key];
                }
                else {
                    generatedConfig[key] = config[key];
                }
            }
        });

        this.name = name;
        this.config = generatedConfig;

        contentInjectInfo._moduleNames.push(name);
        contentInjectInfo.options.moduleConfig[name] = generatedConfig;

        contentInjectInfo._modules.push(this);
    }

    /** 
     * Called when ContentInject requests information about a module to display in the main inject.
     * 
     * **Must return a string**.
     * 
     * If an empty string is returned, ContentInject will not display the module.
     * @param {Boolean} enabled Whether this module is marked as enabled
     * @param {ModuleConfig} config The current config of the module
     * @returns {String} 
    */
    onRequestContent(enabled, config) {
        return "";
    }

    /***
     * Called when recieving a request to open the ContentInject tray. Must return an array containing button information. 
     * If no buttons are wanted to be added to the tray, then return an empty array.
     * 
     * If there's an error whilst adding the button, will log it in the console.
     * @param {Boolean} enabled Whether this module is marked as enabled
     * @param {ModuleConfig} config The current config of the module
     * @returns {TrayButtonInfo[]}
     */
    onRequestTrayButtons(enabled, config) {
        return [];
    }

    /** 
     * Util for generating the status of a module specified
     * Used specifically for the **Module Loaded** tab in the Options
     * @param {ContentInjectModule} contentInjectModule 
    */
    static getStatus(contentInjectModule) {
        let moduleConfig = contentInjectInfo.options.moduleConfig[contentInjectModule.name];

        let moduleName = contentInjectModule.name.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

        if (!moduleConfig) return "";
        else if (moduleConfig.enabled) return "<span style='color: green'>•</span> " + moduleName;
        else return "<span style='color: red'>•</span> " + moduleName;
    }
}


function createInject() {
    if (contentInjectInfo.contentButton) {
        clearInterval(contentInjectInfo.interval);
        if (contentInjectInfo.contentButton.parentNode) contentInjectInfo.contentButton.parentNode.removeChild(contentInjectInfo.contentButton);
    }

    let urlStyle = contentInjectInfo.options.urlStyles.find((style) => style.url == window.location.host);

    let baseID = "";
    let baseKey = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789";

    for (let _index = 0; _index < 30; _index++) {
        baseID += baseKey.charAt(Math.floor(Math.random() * baseKey.length));
    }

    contentInjectInfo.baseID = baseID;
    contentInjectInfo.optionsItemNoBRClass = "content-inject-options-item-nobr-" + contentInjectInfo.baseID;
    
    urlStyle = urlStyle !== undefined ? urlStyle : contentInjectInfo.options.defaultStyle;

    if (!urlStyle.enabled) return;

    contentInjectInfo.currentStyle = urlStyle;
    
    let contentButton = document.createElement("button");
    let { base: baseValues } = contentInjectInfo.options;

    contentButton.textContent = "Loading...";

    // add base styles
    contentInjectInfo.functions.addStyle(contentButton, "contentButton");

    contentButton.style.bottom = (baseValues.bottom + urlStyle.offsetBottom) + "px";
    contentButton.style.left = (baseValues.left + urlStyle.offsetLeft) + "px";

    contentInjectInfo.options.styles["contentButton"].bottom = contentButton.style.bottom;
    contentInjectInfo.options.styles["contentButton"].left = contentButton.style.left;

    contentButton.id = "main-content-" + baseID;

    contentButton.addEventListener("click", (ev) => {
        ev.srcElement.parentNode.removeChild(ev.srcElement);
        clearInterval(contentInjectInfo.interval);
    });

    contentButton.addEventListener("contextmenu", (ev) => {
        ev.preventDefault();
        contentInjectInfo.functions./*showOptions()*/showTray();
    });

    contentInjectInfo.contentButton = contentButton;

    // load interval
    contentInjectInfo.interval = setInterval(contentInjectInfo.functions.update, contentInjectInfo.options.updateTime);

    document.body.appendChild(contentButton);
}
//}