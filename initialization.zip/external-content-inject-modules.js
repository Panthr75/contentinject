class SchoolContentInjectModule extends ContentInjectModule {
    constructor() {
        super("school", {"halfDay": false, "examDay": false, "lateDay": false, "autoDetectDay": true});
        this.currentInfo = {"notInit": true};
    }

    /** @param {String} dayType */
    UpdatePeriodTimes(dayType, curTime = this.ConvertTime(new Date())) {
        let periodTimes = this._periodTimes[dayType];

        if (periodTimes) {
            let notFound = true;
            let foundInfo = {};
            let periodTimeNames = Object.keys(periodTimes);
            periodTimeNames.forEach((subjectName, index) => {
                if (notFound == true) {
                    let periodTime = this.ConvertPeriodTime(periodTimes[subjectName]);
                    if (this.CompareTime(curTime, periodTime) == true) {
                        if (index == periodTimeNames.length - 1 || subjectName == "_DISABLED_") {
                            foundInfo.disableReason = "disabled";
                            notFound = false;
                        }
                    }
                    else {
                        if (index == 0) {
                            foundInfo.disableReason = "before";
                            foundInfo.startTime = periodTimes[periodTimeNames[0]];
                            foundInfo.startTimeNum = this.ConvertPeriodTime(foundInfo.startTime);
                            notFound = false;
                        }
                        else {
                            console.log("WEW")
                            let prevSubject = periodTimeNames[index - 1];

                            foundInfo.name = prevSubject.replace(/_[^_]*_/g, "");
                            foundInfo.nextSubject = subjectName.replace(/_[^_]*_/g, "");

                            foundInfo.startTime = periodTimes[prevSubject];
                            foundInfo.startTimeNum = this.ConvertPeriodTime(foundInfo.startTime);

                            foundInfo.endTime = periodTimes[subjectName];
                            foundInfo.endTimeNum = this.ConvertPeriodTime(foundInfo.endTime);

                            notFound = false;
                        }
                    }
                }
            });
            this.currentInfo = foundInfo;
        }
        else this.currentInfo = {};
    }

    /**
     * @param {Number[]} currentTime 
     * @param {Number[]} periodTime 
     * @returns {Boolean} `true` if currentTime greater than or equal to periodTime. Otherwise returns `false`
    */
    CompareTime(currentTime, periodTime) {
        for (let i = 0, len = currentTime.length; i < len; i++) {
            if (currentTime[i] > periodTime[i]) return true;
            else if (currentTime[i] < periodTime[i]) return false;
        }
        return true;
    }

    /** @param {String} inputTime */
    ConvertPeriodTime(inputTime) {
        return inputTime.split(":").map(period => parseInt(period));
    }

    /** @param {Date} inputTime */
    ConvertTime(inputTime) {
        return [inputTime.getHours(), inputTime.getMinutes(), inputTime.getSeconds()];
    }

    ConvertToTime(inputNumber) {
        let seconds = inputNumber;
        let mins = Math.floor(seconds / 60);
        seconds = seconds % 60;
        let hours = Math.floor(mins/ 60);
        mins = mins % 60;
        return [hours, mins, seconds];
    }

    ConvertToNumber(inputNumbers) {
        return ((inputNumbers[0] * 60) + inputNumbers[1]) * 60 + inputNumbers[2];
    }

    /** @param {Date} inputTime */
    GetTimeRemaining(inputTime) {
        if (this.currentInfo.disableReason) return "";
        else {
            let inputNumber = this.ConvertToNumber(this.ConvertTime(inputTime));

            let endTimeNumber = this.ConvertToNumber(this.currentInfo.endTimeNum);

            let remainingNumbers = this.ConvertToTime(endTimeNumber - inputNumber);

            return `${remainingNumbers[0] > 0 ? remainingNumbers[0] + ":": ""}${remainingNumbers[1] < 10 ? "0" : ""}${remainingNumbers[1]}:${remainingNumbers[2] < 10 ? "0" : ""}${remainingNumbers[2]}`;
        }
    }

    /** @type {Object.<string,Object.<string, string>>} */
    get _periodTimes() {
        return {
            "normalDay": {
                "BEFORE SCHOOL": "7:00:00",
                "INITIAL PASS": "7:39:00",
                "PER 1": "7:45:00",
                "PASS_1_": "8:35:00",
                "PER 2": "8:41:00",
                "PASS_2_": "9:34:00",
                "PER 3": "9:40:00",
                "PASS_3_": "10:30:00",
                "PER 4": "10:36:00",
                "PASS_4_": "11:26:00",
                "PER 5": "11:32:00",
                "PASS_5_": "12:22:00",
                "PER 6": "12:28:00",
                "PASS_6_": "13:18:00",
                "PER 7": "13:24:00",
                "PASS_7_": "14:14:00",
                "PER 8": "14:20:00",
                "AWAIT BUS": "15:10:00",
                "_DISABLED_": "15:35:00"
            },
            "lateDay": {
                "BEFORE SCHOOL": "7:00:00",
                "INITIAL PASS": "8:54:00",
                "PER 1": "9:00:00",
                "PASS_1_": "9:42:00",
                "PER 2": "9:47:00",
                "PASS_2_": "10:29:00",
                "PER 3": "10:34:00",
                "PASS_3_": "11:16:00",
                "PER 4": "11:21:00",
                "PASS_4_": "12:03:00",
                "PER 5": "12:08:00",
                "PASS_5_": "12:49:00",
                "PER 6": "12:54:00",
                "PASS_6_": "13:36:00",
                "PER 7": "13:41:00",
                "PASS_7_": "14:23:00",
                "PER 8": "14:28:00",
                "AWAIT BUS": "15:10:00",
                "_DISABLED_": "15:35:00"
            },
            "halfDay": {
                "BEFORE SCHOOL": "7:00:00",
                "INITIAL PASS": "7:39:00",
                "PER 1": "7:45:00",
                "PASS_1_": "8:11:00",
                "PER 2": "8:17:00",
                "PASS_2_": "8:45:00",
                "PER 3": "8:51:00",
                "PASS_3_": "9:17:00",
                "PER 4": "9:23:00",
                "PASS_4_": "9:49:00",
                "PER 5": "9:55:00",
                "PASS_5_": "10:21:00",
                "PER 6": "10:27:00",
                "PASS_6_": "10:54:00",
                "PER 7": "11:00:00",
                "PASS_7_": "11:27:00",
                "PER 8": "11:33:00",
                "_DISABLED_": "12:00:00"
            }
        }
    }

    getContent(curTime, dayType) {
        if (this.currentInfo.notInit) {
            this.UpdatePeriodTimes(dayType, this.ConvertTime(curTime));
        }
        else if (this.currentInfo.disableReason == "before") {
            if (this.CompareTime(this.ConvertTime(curTime), this.currentInfo.startTimeNum) || !this.CompareTime(this.ConvertTime(curTime), this.currentInfo.endTimeNum)) {
                this.UpdatePeriodTimes(dayType, this.ConvertTime(curTime));
            }
        }
        else if (this.currentInfo.disableReason) {
            //
        }
        else {
            if (this.CompareTime(this.ConvertTime(curTime), this.currentInfo.endTimeNum)) {
                this.UpdatePeriodTimes(dayType, this.ConvertTime(curTime));
            }
        }

        return this.currentInfo.disableReason ? "" : `${this.currentInfo.name} - ${this.GetTimeRemaining(curTime)}`;
    }

    onRequestContent(enabled, config) {
        if (enabled) {
            let curTime = new Date();
            let dayType = "normalDay";
            if (config.autoDetectDay) {
                if ([0, 6].includes(curTime.getDay())) {
                    dayType = "";
                }
                else if (curTime.getDay() == 3) dayType = "lateDay";
            }
            else if (config.halfDay) {
                dayType = "halfDay";
            }
            else if (config.examDay) {
                dayType = "examDay";
            }
            else if (config.lateDay) {
                dayType = "lateDay";
            }
    
            if (this.currentInfo.disableReason) {
                return "";
            }
            else {
                return this.getContent(curTime, dayType);
            }
        }
        else return "";
    }
}