class TimeContentInjectModule extends ContentInjectModule {
    constructor() {
        super("time", {"show_seconds": true, "military_time": false});
    }

    _utilConvertTime(time) {
        if (time < 10) return "0" + time;
        else return time.toString();
    }

    onRequestContent(enabled, config) {
        if (enabled) {
            let d = new Date();
            let hours = d.getHours();
            let minutes = d.getMinutes();
            let prefix = " AM";

            if (config.military_time) {
                prefix = "";
            }
            else {
                if (hours > 12) {
                    hours -= 12;
                    prefix = " PM";
                }

                if (hours === 0) hours = 12;
            }

            let returnString = `${hours}:${this._utilConvertTime(minutes)}`;

            if (config.show_seconds) {
                let seconds = d.getSeconds();
                returnString += `:${this._utilConvertTime(seconds)}`;
            }
            returnString += prefix;

            return returnString;
        }
        else return "";
    }
}

class DateContentInjectModule extends ContentInjectModule {
    constructor() {
        super("date", {"abbrieviated": true, "dayOfWeek": true, "year": true});
    }

    get _abbr() {
        return {"month": ["JAN", "FEB", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUG", "SEP", "OCT", "NOV", "DEC"], "day": ["SUN", "MON", "TUE", "WED", "THUR", "FRI", "SAT"]};
    }

    get _noabbr() {
        return {"month": ["January", "February", "March", "April", "May", "June", "July", "August", "Septempber", "October", "November", "December"], "day": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]};
    }

    onRequestContent(enabled, config) {
        if (enabled) {
            let d = new Date();

            let month = d.getMonth();
            let year = d.getFullYear();
            let day = d.getDate();
            let dayOfWeek = d.getDay();

            let returnString = "";

            if (config.abbrieviated) {
                if (config.dayOfWeek) returnString += this._abbr.day[dayOfWeek] + ", ";

                returnString += this._abbr.month[month];
                returnString += " " + day;
            }
            else {
                if (config.dayOfWeek) returnString += this._noabbr.day[dayOfWeek] + ", ";

                returnString += this._noabbr.month[month];
                returnString += " " + day;
            }

            if (config.year) returnString += ", " + year;

            return returnString;
        }
        else return "";
    }
}

class BatteryTimeContentInjectModule extends ContentInjectModule {
    constructor() {
        super("battery", {"show_timeleft": true});
        this.batteryInfo = {"hours": "00", "minutes": "00", "level": "0%"};
    }


    static _utilConvertTime(time) {
        if (time < 10) return "0" + time;
        else return time.toString();
    }

    onRequestContent(enabled, config) {
        if (enabled) {
            navigator.getBattery().then(battery => {
                var battime = battery.charging ? battery.chargingTime : battery.dischargingTime;

                var mins = battime / 60;
                var hours = Math.floor(mins/ 60);
                mins = Math.round(mins - (hours * 60));
                
                this.batteryInfo.hours = BatteryTimeContentInjectModule._utilConvertTime(hours);

                this.batteryInfo.minutes = BatteryTimeContentInjectModule._utilConvertTime(mins);

                this.batteryInfo.level = (Math.round(battery.level * 100)) + "%";
            });

            return this.batteryInfo.level + 
            (config.show_timeleft ? "; " + 
            this.batteryInfo.hours + ":" + 
            this.batteryInfo.minutes + " left": "");
        }
        else return "";
    }
}

class LagMeterContentInjectModule extends ContentInjectModule {
    constructor() {
        super("lagmeter", {"spinner": false});
        this.spinState = -1;
        this.spinCyles = ["|", "/", "—", "\\"];
    }

    onRequestContent(enabled, config) {
        if (enabled) {
            if (!this.startLag) {
                this.lagTime = 0;
                this.startLag = Date.now();
            }
            else {
                let endTime = Date.now();
                this.lagTime = endTime - this.startLag - contentInjectInfo.options.updateTime;
                if (this.lagTime < 0) this.lagTime = 0;
                this.startLag = endTime;
            }
            
            let dots = "";
            
            if (config.spinner == true) {
                dots += "; ";
                this.spinState++;
                
                if (this.spinState >= this.spinCyles.length) {
                    this.spinState = 0;
                }
                dots += this.spinCyles[this.spinState];
            }
            
            return this.lagTime + "ms" + dots;
        }
        else return "";
    }
}

class CodeRunnerContentInjectModule extends ContentInjectModule {
    constructor() {
        super("coderunner", {"usePrompt": true, "testing": "test", "wow": 0});
    }

    requestCodeToBeRun(enabled, config) {
        if (config.usePrompt) {
            try {
                alert(JSON.stringify(eval(prompt("Enter JavaScript code to evaluate"))));
            }
            catch(err) {
                alert("ERROR\n" + JSON.stringify(err));
            }
        }
    }
    
    
    /** @returns {TrayButtonInfo[]} */
    onRequestTrayButtons(enabled, config) {
        if (enabled) {
            return [{"content": "Run Code", "deleteTrayWhenClicked": false, "onClickCallback": this.requestCodeToBeRun}];
        }
        else return [];
    }
}